package fractions;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AppliFraction extends JFrame implements ActionListener {

	private JFrame frmFraction;
	private JTextField textFieldevaluer;
	private JTextField lblegypt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppliFraction window = new AppliFraction();
					window.frmFraction.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppliFraction() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmFraction = new JFrame();
		frmFraction.setTitle("Fraction");
		frmFraction.setBounds(100, 100, 350, 200);
		frmFraction.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(100, 100, 350, 200);
		frmFraction.getContentPane().add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblevaluer = new JLabel("Evaluer une expression fraction");
		lblevaluer.setForeground(Color.BLUE);
		panel.add(lblevaluer);
		
		textFieldevaluer = new JTextField();
		textFieldevaluer.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyChar() == KeyEvent.VK_EQUALS) {
    	            String expression = textFieldevaluer.getText().replace("=", "").trim();                	
    	            Fraction result = Fraction.evalueExpression(expression);
    	            textFieldevaluer.setText(expression+"="+result.toString());

                }
            }
        });


		panel.add(textFieldevaluer);
		textFieldevaluer.requestFocusInWindow();
		
		JPanel panel_des = new JPanel();
		panel_des.setBackground(new Color(128, 128, 128));
		panel.add(panel_des);
		
		JLabel lbldes = new JLabel("Taper une expression terminée par = (barre de l'expression est /)");
		lbldes.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel_des.add(lbldes);
		
		JLabel lblegypti = new JLabel("Fractions égyptiennes");
		lblegypti.setForeground(Color.BLUE);
		panel.add(lblegypti);
		
		lblegypt = new JTextField();
		panel.add(lblegypt);
		lblegypt.setColumns(10);
	}

	@Override
	public void actionPerformed(ActionEvent e) {


	}

}
