package fractions;

public class Fraction  {
	private int n;
	private int d;


	public Fraction() {
		this(0, 1);
	}

	// construit la fraction 0/1.
	public Fraction(int n) {
		this(n, 1);
	}

	// construit la fraction n/1.
	public Fraction(int n, int d) {
		this.n = n;
		this.d = d;
		finInit();
	}
	// construit la fraction n/d.

	public Fraction(String s) {
		int iBarre = s.indexOf('/');
		if (iBarre == -1)
			throw new IllegalArgumentException();
		try {
			n = Integer.parseInt(s.substring(0, iBarre));
			d = Integer.parseInt(s.substring(iBarre + 1));
		} catch (NumberFormatException e) {
		}
		;
	}

	private void finInit() {
		if (d == 0) {
			throw new IllegalArgumentException("On peut pas diviser par 0");
		}
		reduire();
		if (d < 0) {
			this.n = -n;
			this.d = -d;
		}
	}
	public void reduire() {
	    int pgcd = pgcd(n, d);
	    n /= pgcd;
	    d /= pgcd;
	}

	public static int ppcm(int a, int b) {
		return a * b / pgcd(a, b);
	}

	public static int pgcd(int a, int b) {
		int r = a % b;
		if (r == 0)
			return b;
		else {
			while (b != 0)
				r = a % b;
		a = b;
		b = r;}
		return a;
		//for (int r=a%b; r!=0; a=b, b=r, r=a%b)
		//	;
		//return b;
	}

	// construit une fraction d'après son expression écrite dans s
	public String toString() {
		return n + "/" + d;
	}

	// Retourne une String contenant l'expression de this.
	public int getNumerateur() {
		return n;
	}

	// Accesseur en lecture pour le numérateur.
	public int getDenominateur() {
		return d;
	}

	// Accesseur en lecture pour le dénominateur.
	public void setNumerateur(int n) {
		this.n = n;
	}

	// Accesseur en écriture pour le numérateur.
	public void setDenominateur(int d) {
		this.d = d;
		finInit();
	}
	// Accesseur en écriture pour le dénominateur.

	public static Fraction valueOf(String s) {
		String[] parts = s.split("/");
		int n = Integer.parseInt(parts[0]);
		int d = Integer.parseInt(parts[1]);
		return new Fraction(n, d);
	}
	// Retourne une Fraction dont l'expression est dans s, s est de la forme :
	// expression d'un entier positif,
//	suivie de '/', suivi de l'expression d'un entier positif.

	public Fraction plus(Fraction f) {
		n = this.n * ppcm(this.d, f.d) / this.d + f.n * ppcm(this.d, f.d) / f.d;
		d = ppcm(this.d, f.d);
		return this;
	}
	// Retourne le résultat de l'addition de this et f.

	public Fraction moins(Fraction f) {
		n = this.n * ppcm(this.d, f.d) / this.d - f.n * ppcm(this.d, f.d) / f.d;
		d = ppcm(this.d, f.d);
		return this;
	}

	// Retourne le résultat de la soustraction de this et f.
	public Fraction fois(Fraction f) {
		n = this.n * f.n;
		d = this.d * f.d;
		return this;

	}

	// Retourne le résultat de la multiplication de this par f.
	public Fraction diviseePar(Fraction f) {
		if (d == 0) {
			throw new IllegalArgumentException("On ne peut pas diviser par 0");
		} else {
			n = this.n * f.d;
			d = this.d * f.n;
		}
		return this;

	}
	// Retourne le résultat de la division de this par f.

	public int compareTo(Fraction f) {

		if ((this.moins(f).getNumerateur() < 0) || (this.moins(f).getDenominateur() < 0))
			return -1;
		else if (this.moins(f).getNumerateur() == 0)
			return 0;
		else
			return 1;

		// return moins(f).n;
	}
	// Retourne un int négatif si this est inférieur à f, positif si this est
	// supérieur à f, nul si this estéquivalent à f.

	public boolean equals(Object obj) {

		return (obj instanceof Fraction) && this.compareTo((Fraction) obj) == 0;
	}
	// Retourne true si et seulement si this est équivalent à obj.

	public static boolean estOperateur (char c) {
		return c == '*'|| c == '+'||c == '-'||c == ':';
	}
	
	public static Fraction appliqueOperation (char op, Fraction f1, Fraction f2) {
		if(op=='+')
			return f1.plus(f2); 
		if(op=='-')
			return f1.moins(f2); 
		if(op=='*')
			return f1.fois(f2); 
		if(op==':')
			return f1.diviseePar(f2); 
		throw new RuntimeException ("inconnue operateur"+op);
	}
	
	public static Fraction evalueExpression (String s) {
		int i, iOp;
		Fraction acc, f;
		for (i=0; i<s.length()&& !(estOperateur(s.charAt(i))); i++)
			;
		iOp=i;
		acc= valueOf(s.substring(0, i));
		for (i++; i<s.length(); i++)
			if (estOperateur(s.charAt(i))) {
				f = new Fraction (s.substring(iOp+1, i));
				acc = appliqueOperation(s.charAt(iOp), acc, f);
				iOp=i;
			}
		f= new Fraction (s.substring(iOp+1));
		acc = appliqueOperation(s.charAt(iOp), acc, f);
		return acc;
	}
	
	public String formeEgyptienne() {
		if (compareTo(new Fraction(1))>0 || compareTo(new Fraction())<0)
			throw new RuntimeException ("pas intéressants pour cette fraction : "+ this);
		int d=2;
		Fraction restant= this, candidate = new Fraction (1, 2);
		String res = "";
		for ( ; restant.getNumerateur()!= 1; d++, candidate = new Fraction (1, d))
			if (candidate.compareTo(restant)<= 0) {
				res += candidate + "+";
				restant = restant.moins(candidate);
			}
		res += restant;
		
		return res;
	}
	
	

	
	

}
