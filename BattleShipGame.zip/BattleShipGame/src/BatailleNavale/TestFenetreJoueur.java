package BatailleNavale;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JLabel;

public class TestFenetreJoueur {

	private JFrame frmTestfenetrejoueur;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestFenetreJoueur window = new TestFenetreJoueur();
					window.frmTestfenetrejoueur.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TestFenetreJoueur() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmTestfenetrejoueur = new JFrame();
		frmTestfenetrejoueur.setTitle("testFenetreJoueur");
		frmTestfenetrejoueur.setBounds(100, 100, 579, 405);
		frmTestfenetrejoueur.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTestfenetrejoueur.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		frmTestfenetrejoueur.getContentPane().add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(0, 2, 0, 0));
		
		JLabel GrilleTirText = new JLabel("Shooting Grid");
		panel.add(GrilleTirText);
		
		JLabel GrilleDefenseText = new JLabel("Defense grid");
		panel.add(GrilleDefenseText);
		
		JPanel gridPanel = new JPanel();
		gridPanel.setBackground(Color.PINK);
		frmTestfenetrejoueur.getContentPane().add(gridPanel, BorderLayout.CENTER);
		gridPanel.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel attackGrid = new JPanel();
		attackGrid.setBackground(new Color(255, 160, 122));
		gridPanel.add(attackGrid);
		
		JPanel defenceGrid = new JPanel();
		defenceGrid.setBackground(new Color(135, 206, 250));
		gridPanel.add(defenceGrid);
	}

}
