package BatailleNavale;
import java.util.Scanner;

public class JoueurTexte extends JoueurAvecGrille {
	
       private Scanner sc;
       
       public JoueurTexte(GrilleNavale g, String nom) {
           super(g, nom);
           this.sc = new Scanner(System.in);
       }
       public JoueurTexte(GrilleNavale g) {
           super(g);
           this.sc = new Scanner(System.in);
       }
       public void retourAttaque(Coordonnee c, int etat) {
           if (etat == Joueur.TOUCHE)
               System.out.println("Tir " + c+" from the attacker: You have hit a ship");
           else if (etat == Joueur.COULE)
               System.out.println("Tir " + c+" from the attacker: You have sunk a ship");
           else if (etat == Joueur.A_L_EAU)
               System.out.println("Tir " + c+" from the attacker: You shot into the water");
           else if (etat == Joueur.GAMEOVER)
               System.out.println("Tir " + c+" the attacker: WIN :) ");
       }


       public void retourDefense(Coordonnee c, int etat) {
           if (etat == Joueur.TOUCHE)
               System.out.println("Tir " + c+ " from the defender: Your ship has been hit by gunfire");
           else if (etat == Joueur.COULE)
               System.out.println("Tir " + c+ " from the defender: Your ship has been sunk");
           else if (etat == Joueur.A_L_EAU)
               System.out.println("Tir " + c+" from the defender: A shot by the attacker fell into the water");
           else if (etat == Joueur.GAMEOVER)
               System.out.println("Tir " + c+" the defender: LOST :( ");


       }
       public Coordonnee choixAttaque() {
//           System.out.println("Entrez grille : \n");
           System.out.println("\nYou are : " + getNom());
           System.out.println("Enter the coordinates of you want to attack : ");
           String coord = sc.nextLine();//lire les coordonnées
           Coordonnee c = new Coordonnee(coord);//créer un objet coordonnée
           return c;//retourner les coordonnées
       }
   }
